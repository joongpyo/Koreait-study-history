/*
1. jdk 설치
  (1) www.oracle.com 다운로드 메뉴에서 jdk 다운로드
  (2) 내 PC -> 속성 -> 고급 시스템 설정
      1) JAVA_HOME : jdk 설치 폴더 등록
      2) Path 등록 : jdk설치 폴더\bin

2. 이클립스 설치
  (1) www.eclipse.org
     1) 이클립스 다운로드
     2) 압축 해제
     3) 이클립스 실행 후 작업 폴더 등록
 */